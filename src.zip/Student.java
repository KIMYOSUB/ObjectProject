import java.io.*;

public class Student {
    private String name;
    private String student_num;
    private String pw;

    public class FileManager {
        File fp;
        BufferedWriter fw;
        BufferedReader fr;

        private String FName = "DB.txt";
        private String DateTok = "Date ";
        private String TimeTok = "  Time ";
        private String SnoringTok = "Snoring : ";
        private String MovementTok = "  Movement : ";
        private String SleepTok = "  Sleep : ";

        private int index = 0;

        public int num = 0;
        public ShortTimeVacant data[] = new ShortTimeVacant[100];


        FileManager() {
            fp = new File(FName);
            if (fp.exists())
                fp.delete();
        }

        FileManager(String FName) {
            this.FName = FName;
            fp = new File(FName);
            if (fp.exists())
                fp.delete();
        }

        public boolean fileWrite(String date, String time, int snoring, int movement) {
            String buffer = DateTok + date + TimeTok + time + " | " + SnoringTok + snoring + MovementTok + movement + SleepTok + ((snoring < 1 && movement < 1) ? true : false);

            try {
                fw = new BufferedWriter(new FileWriter(fp, true));
                fw.write(buffer);
                fw.newLine();
                fw.close();
                num++;
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }

        }

        public boolean fileRead(String Date) {
            String buffer;
            index = 0;
            try {
                fr = new BufferedReader(new FileReader(fp));
                buffer = fr.readLine();

                while (buffer != null) {
                    if (buffer.indexOf(Date) > 0) {
                        System.out.println(buffer);
                        decode(buffer);
                    }
                    buffer = fr.readLine();
                }
                fr.close();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }

        }

        public void decode(String buffer) {
        	
            data[index] = new ShortTimeVacant();
            int i = buffer.indexOf(DateTok);
            i = i + DateTok.length();
            data[index].setDate(buffer.substring(i, i + 8));

            i = buffer.indexOf(TimeTok);
            i = i + TimeTok.length();
            data[index].setTime(buffer.substring(i, i + 4));

            i = buffer.indexOf(SnoringTok);
            i = i + SnoringTok.length();
            data[index].setSnoring(buffer.substring(i, i + 1));

            i = buffer.indexOf(MovementTok);
            i = i + MovementTok.length();
            data[index].setMovement(buffer.substring(i, i + 1));

            data[index].setSleep();

            index++;
        }

        public int getIndex() {
            return index;
        }


    }
}