
public class Administrator {
    private String ad_id;
    private String ad_password;

    private BackList root;
    private int searchPath;

    public Administrator() {
        root = null;
    }

    public boolean isEmpty() {
        return root == null;
    } //트리가 비어있는지 검사

    public void makeEmpty() {
        root = null;
    } //트리 내부의 모든 노드의 연결을 해제, OS에서 제거

    public void insert(int data) {
        root = insert(data, root);
    } //main에서 사용되는 삽입 메소드

    private int height(BackList node) {
        return node == null ? -1 : node.getHeight();
    } //전달된 노드의 높이를 출력, 각 노드에 높이가 저장되어있음

    private BackList insert(int target, BackList t) {
        if (t == null)
            t = new BackList(target);
        else if (target < t.getData()) {
            t.setLeft(insert(target, t.getLeft()));
            if (height(t.getLeft()) - height(t.getRight()) == 2)
                if (target < t.getLeft().getData())
                    t = rotateLeft(t);
                else
                    t = doubleLeft(t);
        } else if (target > t.getData()) {
            t.setRight(insert(target, t.getRight()));
            if (height(t.getRight()) - height(t.getLeft()) == 2)
                if (target > t.getRight().getData())
                    t = rotateRight(t);
                else
                    t = doubleRight(t);
        } else ;

        t.setHeight(Math.max(height(t.getLeft()), height(t.getRight())) + 1);
        return t;
    } //class내부에서 사용되는 삽입 메소드

    private BackList rotateLeft(BackList node) {
        BackList temp = node.getLeft();
        node.setLeft(temp.getRight());
        temp.setRight(node);
        node.setHeight(Math.max(height(node.getLeft()), height(node.getRight())) + 1);
        temp.setHeight(Math.max(height(temp.getLeft()), node.getHeight()) + 1);
        return temp;
    } //LL 단일회전 메소드

    private BackList rotateRight(BackList node) {
        BackList temp = node.getRight();
        node.setRight(temp.getLeft());
        temp.setLeft(node);
        node.setHeight(Math.max(height(node.getLeft()), height(node.getRight())) + 1);
        temp.setHeight(Math.max(height(temp.getRight()), node.getHeight()) + 1);
        return temp;
    } //RR 단일회전 메소드

    private BackList doubleLeft(BackList node) {
        node.setLeft(rotateRight(node.getLeft()));
        return rotateLeft(node);
    } //RL 이중회전 메소드

    private BackList doubleRight(BackList node) {
        node.setRight(rotateLeft(node.getRight()));
        return rotateRight(node);
    } //LR 이중회전 메소드

    public int countNodes() {
        return countNodes(root);
    } //main에서 트리의 전체 높이를 계산하는 메소드

    private int countNodes(BackList node) {
        if (node == null)
            return 0;
        else {
            int level = 1;
            level = level + countNodes(node.getLeft());
            level = level + countNodes(node.getRight());
            return level;
        }
    } //class에서 트리의 높이를 계산하는 메소드

    public int search(int key) {
        searchPath = 0;
        if (search(root, key)) {
            System.out.print("Searching [" + key + "] Succeed");
            return searchPath;
        } else {
            System.out.println("Searching [" + key + "] Fail.");
            return -1;
        }
    } //main에서 트리 내의 key를 검색하는 메소드, 소요 경로수 반환

    private boolean search(BackList node, int key) {
        boolean found = false;
        while ((node != null) && !found) {
            int thisKey = node.getData();
            searchPath++;
            if (key < thisKey)
                node = node.getLeft();
            else if (key > thisKey)
                node = node.getRight();
            else {
                found = true;
                break;
            }
            found = search(node, key);
        }
        return found;
    } //class에서 트리 내의 key를 검색하는 메소드

    public void inorder() {
        inorder(root);
    } //main에서 트리의 모든 노드를 inorder로 순회하기 위한 메소드

    private void inorder(BackList node) {
        if (node != null) {
            inorder(node.getLeft());
            System.out.print(node.getData() + " ");
            inorder(node.getRight());
        }
    } //class에서 트리의 모든 노드를 inorder로 순회하기 위한 메소드

    public void preorder() {
        preorder(root);
    } //main에서 트리의 모든 노드를 preorder로 순회하기 위한 메소드

    private void preorder(BackList node) {
        if (node != null) {
            System.out.print(node.getData() + " ");
            preorder(node.getLeft());
            preorder(node.getRight());
        }
    } //class에서 트리의 모든 노드를 preorder로 순회하기 위한 메소드

    public void postorder() {
        postorder(root);
    } //class에서 트리의 모든 노드를 postorder로 순회하기 위한 메소드

    private void postorder(BackList node) {
        if (node != null) {
            postorder(node.getLeft());
            postorder(node.getRight());
            System.out.print(node.getData() + " ");
        }
    } //class에서 트리의 모든 노드를 postorder로 순회하기 위한 메소드

    public boolean add(String name, String student_num) {
        return false;

    }

    public boolean delete(String name, String student_num) {
        return false;

    }
}
