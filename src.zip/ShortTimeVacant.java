
public class ShortTimeVacant {
    public String name;
    public String student_num;

    public boolean checkVacant(int seat) {
        return false;

    }

    public boolean antitheftAlarm(int seat) {
        return false;

    }

    public boolean movement() {
        return false;

    }

    private String date;
    private String time;
    private int snoring;
    private int movement;
    private boolean sleep;

    ShortTimeVacant() {
        date = null;
        time = null;
        snoring = -1;
        movement = -1;
        sleep = false;
    }

    public void setSleep() {
        if (snoring >= 1 && movement >= 1)
            sleep = false;
        else
            sleep = true;
    }


    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setSnoring(String snoring) {
        this.snoring = Integer.parseInt(snoring);
    }

    public void setMovement(String move) {
        this.movement = Integer.parseInt(move);
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public int getSnoring() {
        return snoring;
    }

    public int getMovement() {
        return movement;
    }

    public boolean getSleep() {
        return sleep;
    }
}
