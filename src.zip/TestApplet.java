import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class TestApplet extends Applet {
    public TestApplet() {
        this.setBackground(Color.orange);
    }

    public class EFrame extends Frame implements KeyListener, ActionListener {
        private boolean run = false;
        private boolean even = true;

        private Label type = new Label("Encoding Type", Label.LEFT);
        private Label input = new Label("Input", Label.CENTER);
        private Label show = new Label("Ready", Label.CENTER);
        private Label up = new Label("+5V", Label.RIGHT);
        private Label down = new Label("-5V", Label.RIGHT);
        private Label ground = new Label("0V", Label.RIGHT);
        private Button start = new Button("Start");
        private Button clear = new Button("Clear");
        private TextField bitIN = new TextField();
        private Choice encoding = new Choice();

        private StudyGroup data = new StudyGroup();
        private SeatInfo en = new SeatInfo();

        {
            encoding.add("Menchester");
            encoding.add("Defferential Menchester");
        }

        private GridBagLayout gBag = new GridBagLayout();

        public EFrame() {
            this.setLayout(gBag);

            this.insert(type, 0, 0, 2, 1, 5);
            this.insert(encoding, 2, 0, 3, 1, 5);
            this.insert(start, 5, 0, 2, 1, 5);
            this.insert(clear, 7, 0, 2, 1, 5);
            this.insert(input, 9, 0, 1, 1, 5);
            this.insert(bitIN, 10, 0, 1, 1, 5);
            this.insert(show, 11, 0, 1, 1, 5);
            this.insert(up, 0, 2, 1, 1, 10);
            this.insert(ground, 0, 3, 1, 1, 15);
            this.insert(down, 0, 4, 1, 1, 15);

            super.setResizable(false);
            this.bitIN.addKeyListener(this);
            this.start.addActionListener(this);
            this.clear.addActionListener(this);

            this.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    System.exit(0);
                }
            });

        }

        private void insert(Component cmpt, int x, int y, int w, int h, int gap) {
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.CENTER;
            gbc.gridx = x;
            gbc.gridy = y;
            gbc.gridwidth = w;
            gbc.gridheight = h;
            gbc.insets = new Insets(gap, 5, gap, 5);
            this.gBag.setConstraints(cmpt, gbc);
            this.add(cmpt);
        }

        public void keyTyped(KeyEvent e) {
            bitIN.setText("\0");

            if (run == false)
                return;

            if (e.getKeyChar() == '1' || e.getKeyChar() == '0') {
                show.setText("Done");
                {
                    if (e.getKeyChar() == '0')
                        data.enqueue((byte) 0);
                    else if (e.getKeyChar() == '1')
                        data.enqueue((byte) 1);
                }
                repaint();
                data.printAll();
            } else {
                show.setText("Error");
            }
            return;
        }

        public void keyReleased(KeyEvent e) {
        }

        public void keyPressed(KeyEvent e) {

        }

        public void actionPerformed(ActionEvent e) {
            Object obj = e.getSource();
            if (obj == start) {
                run = !run;
                if (run)
                    show.setText("Start");
                else
                    show.setText("Pause");
                repaint();
            } else if (obj == clear) {
                if (run)
                    show.setText("Clear");
                else
                    show.setText("Ready");
                data.reset();
                repaint();
                data.printAll();
            }
            return;
        }


        @Override
        public void paint(Graphics g) {
            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(57, 68, 464, 140);

            g.setColor(Color.WHITE);
            {
                int temp = 57;
                for (int i = 0; i < 16; i++)
                {
                    g.drawLine(temp, 68, temp, 207);
                    temp = temp + 29;
                }
            }
            g.setColor(Color.gray);
            g.drawLine(58, 86, 520, 86);
            g.drawLine(58, 186, 520, 186);

            g.setColor(Color.DARK_GRAY);
            g.drawLine(58, 136, 520, 136);


            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(2, BasicStroke.CAP_SQUARE, 0));
            g2.setColor(Color.BLUE);

            int temp = 58;
            String str;

            if (run) {
                if (encoding.getSelectedIndex() == 0) {

                    for (int i = 0; i < 16; i++) {
                        int tm;
                        byte curBit = data.getBit(i + 1);

                        if (i == 0)
                            tm = en.MenchEncoding(curBit, (byte) -1);
                        else
                            tm = en.MenchEncoding(curBit, data.getBit(i));

                        switch (tm) {
                            case -2:
                                g2.drawLine(temp, 186, temp, 86);
                                g2.drawLine(temp, 86, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 27, 186);
                                break;
                            case -1:
                                g2.drawLine(temp, 186, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 27, 86);
                                break;
                            case 1:
                                g2.drawLine(temp, 86, temp, 186);
                                g2.drawLine(temp, 86, temp + 14, 86);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 186, temp + 27, 186);
                                break;
                            case 2:
                                g2.drawLine(temp, 186, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 27, 86);
                                break;
                            case 3:
                                g2.drawLine(temp, 86, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 27, 186);
                                break;
                            case 4:
                                g2.drawLine(temp, 86, temp, 186);
                                g2.drawLine(temp, 186, temp + 14, 186);
                                g2.drawLine(temp + 14, 86, temp + 14, 186);
                                g2.drawLine(temp + 14, 86, temp + 27, 86);
                                break;
                            case 0:
                            default:
                                g2.drawLine(temp, 186, temp + 27, 186);
                                break;
                        }
                        if (curBit == -1)
                            str = "-";
                        else
                            str = curBit + "";
                        g.drawString(str, temp + 11, 203);
                        temp = temp + 29;
                    }
                } else if (encoding.getSelectedIndex() == 1) {

                    boolean evTemp = even;

                    for (int i = 0; i < 16; i++) {

                        int tm;
                        byte curBit = data.getBit(i + 1);

                        if (curBit == 1)
                            evTemp = !evTemp;

                        if (i == 0) {
                            tm = en.defMenchEncoding(curBit, (byte) -1, evTemp);
                        } else
                            tm = en.defMenchEncoding(curBit, data.getBit(i), evTemp);

                        switch (tm) {
                            case -2:
                                g2.drawLine(temp, 186, temp, 86);
                                g2.drawLine(temp, 86, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 27, 186);
                                break;
                            case -1:
                                g2.drawLine(temp, 186, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 27, 86);
                                break;
                            case 1:
                                g2.drawLine(temp, 86, temp, 186);
                                g2.drawLine(temp, 86, temp + 14, 86);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 186, temp + 27, 186);
                                break;
                            case 2:
                                g2.drawLine(temp, 86, temp + 14, 86);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 186, temp + 27, 186);
                                break;
                            case 3:
                                g2.drawLine(temp, 86, temp, 186);
                                g2.drawLine(temp, 186, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 27, 86);
                                break;
                            case 4:
                                g2.drawLine(temp, 186, temp + 14, 186);
                                g2.drawLine(temp + 14, 186, temp + 14, 86);
                                g2.drawLine(temp + 14, 86, temp + 27, 86);
                                break;
                            case 0:
                            default:
                                g2.drawLine(temp, 186, temp + 27, 186);
                                break;
                        }

                        if (curBit == -1)
                            str = "-";
                        else
                            str = curBit + "";
                        g.drawString(str, temp + 11, 203);
                        temp = temp + 29;
                    }
                }

            }
        }
    }
}