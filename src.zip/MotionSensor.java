
public class MotionSensor {
	public boolean movement(){
		return false;
	}

	private ReadingRoom header = new ReadingRoom();
	private ReadingRoom trailer = new ReadingRoom();
	private String ListName;
	private int nodeNum = 0;

	public MotionSensor() { 
		header.setNext(trailer);
		trailer.setPrev(header);
		this.ListName = null;
	}

	public MotionSensor(String ListName) {
		header.setNext(trailer);
		trailer.setPrev(header);
		this.ListName = ListName;
	}

	public void insertLast(int[] value, String runNum) {
		ReadingRoom nodeNew = new ReadingRoom(trailer.getPrev(), trailer, value, runNum);
		trailer.getPrev().setNext(nodeNew);
		trailer.setPrev(nodeNew);
		nodeNum++;
	}

	public void insertFirst(int[] value, String runNum) { 
		ReadingRoom nodeNew = new ReadingRoom(header.getNext(), header, value, runNum);
		header.getNext().setPrev(nodeNew);
		header.setNext(nodeNew);
		nodeNum++;
	} 

	public boolean insertBefore(int n, int[] value, String runNum) {
		ReadingRoom temp = header.getNext();
		int index = 0;
		while (temp != trailer) {
			if (index == n) {
				ReadingRoom nodeNew = new ReadingRoom(temp.getPrev(), temp, value, runNum);
				temp.getPrev().setNext(nodeNew);
				temp.setPrev(nodeNew);
				nodeNew.setData(value);
				nodeNum++;
				return true;
			}
			temp = temp.getNext();
			index++;
		}
		return false;
	} 

	public boolean insertAfter(int n, int[] value, String runNum) {
		ReadingRoom temp = header.getNext();
		int index = 0;
		while (temp != trailer) {
			if (index == n) {
				ReadingRoom nodeNew = new ReadingRoom(temp, temp.getNext(), value, runNum);
				temp.getNext().setPrev(nodeNew);
				temp.setNext(nodeNew);
				nodeNew.setData(value);
				nodeNum++;
				return true;
			}
			temp = temp.getNext();
			index++;
		}
		return false;
	} 

	public ReadingRoom removeNode(int n) {
		ReadingRoom temp = header.getNext();
		int index = 0;
		while (temp != trailer) {
			if (index == n) {
				ReadingRoom data = temp;
				temp.getNext().setPrev(temp.getPrev());
				temp.getPrev().setNext(temp.getNext());
				nodeNum--;
				return data;
			}
			temp = temp.getNext();
			index++;
		}
		return null;
	} 

	public ReadingRoom removeFirst() {
		ReadingRoom temp = header.getNext();
		ReadingRoom data = temp;
		temp.getNext().setPrev(temp.getPrev());
		temp.getPrev().setNext(temp.getNext());
		nodeNum--;
		return data;
	} 

	public ReadingRoom getHeader() {
		return header;
	}

	public ReadingRoom getTrailer() {
		return trailer;
	}

	public String getName() {
		return ListName;
	}

	public void printAll() {
		ReadingRoom temp = header.getNext();
		System.out.println(ListName);
		if (temp == trailer)
			System.out.println("> Empty");
		while (temp != trailer) {
			System.out.print("> Run " + temp.getRunNum() + " : ");
			temp.printData();
			temp = temp.getNext();
		}
	}

	public boolean isEmpty() {
		if (nodeNum == 0)
			return true;
		else
			return false;
	} 
}
