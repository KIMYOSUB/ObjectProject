class BackList {
    private BackList left;
    private BackList right;
    private int data;
    private int height;

    BackList() {
        left = null;
        right = null;
        data = 0;
        height = 0;
    }

    BackList(int n) {
        left = null;
        right = null;
        data = n;
        height = 0;
    }

    //이하는 캡슐화를 보장하기 위한 메소드들
    public BackList getLeft() {
        return left;
    }

    public BackList getRight() {
        return right;
    }

    public int getData() {
        return data;
    }

    public int getHeight() {
        return height;
    }

    public void setLeft(BackList left) {
        this.left = left;
    }

    public void setRight(BackList right) {
        this.right = right;
    }

    public void setData(int data) {
        this.data = data;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}


