
public class Absence {

    private void merge(int[] run1, int[] run2, int[] result) {
        int temp1, r1 = 0;
        int temp2, r2 = 0;
        int i = 0;

        while ((r1 < run1.length) && (r2 < run2.length)) { //두 배열 중 하나가 끝날 때까지 반복
            temp1 = run1[r1];
            temp2 = run2[r2];

            if (temp1 < temp2) {
                result[i] = temp1;
                r1++;
            } else if (temp2 < temp1) {
                result[i] = temp2;
                r2++;
            }
            i++;
        }

        if (r1 >= run1.length) { //끝난 배열에 따라서 나머지 배열 복사
            for (int j = r2; j < run2.length; j++) {
                result[i] = run2[j];
                i++;
            }
        } else if (r2 >= run2.length) {
            for (int j = r1; j < run1.length; j++) {
                result[i] = run1[j];
                i++;
            }
        }
        return;
    } //두 배열을 하나로 합치는 메소드

    public void polyPhaseMerge(MotionSensor f1, MotionSensor f2, MotionSensor f3) {

        ReadingRoom input1;
        ReadingRoom input2;

        while ((f1.isEmpty() ^ f2.isEmpty() ^ f3.isEmpty())) { //ExOR을 이용해서 두개의 파일이 빌 때까지 반복.
            if (f1.isEmpty()) { //빈 파일을 출력파일로 해서 합병 진행. 두 파일중 하나가 빌 때까지 반복
                while (!f2.isEmpty() && !f3.isEmpty()) {

                    input1 = f2.removeFirst();
                    input2 = f3.removeFirst();

                    int[] temp = new int[input1.getData().length + input2.getData().length];
                    merge(input1.getData(), input2.getData(), temp);
                    f1.insertLast(temp, input1.getRunNum() + "+" + input2.getRunNum());
                }
            } else if (f2.isEmpty()) {
                while (!f1.isEmpty() && !f3.isEmpty()) {

                    input1 = f1.removeFirst();
                    input2 = f3.removeFirst();

                    int[] temp = new int[input1.getData().length + input2.getData().length];
                    merge(input1.getData(), input2.getData(), temp);
                    f2.insertLast(temp, input1.getRunNum() + "+" + input2.getRunNum());
                }
            } else if (f3.isEmpty()) {
                while (!f1.isEmpty() && !f2.isEmpty()) {

                    input1 = f1.removeFirst();
                    input2 = f2.removeFirst();

                    int[] temp = new int[input1.getData().length + input2.getData().length];
                    merge(input1.getData(), input2.getData(), temp);
                    f3.insertLast(temp, input1.getRunNum() + "+" + input2.getRunNum());
                }
            }
        }
        return;
    } //다단계 합병 과정

    public void heapSort(int[] data) {
        int len = data.length;
        for (int i = len / 2; i > 0; i--)
            downHeap(i, len, data);
        do {
            int temp = data[0];
            data[0] = data[len - 1];
            data[len - 1] = temp;
            len = len - 1;
            downHeap(1, len, data);
        } while (len > 0);
    } //배열의 데이터는 힙정렬 사용

    private void downHeap(int i, int len, int[] data) {
        int j;
        int temp = data[i - 1];
        while (i <= len / 2) {
            j = 2 * i;

            if ((j < len) && (data[j - 1] < data[j]))
                j++;
            if (temp >= data[j - 1])
                break;

            data[i - 1] = data[j - 1];
            i = j;
        }
        data[i - 1] = temp;
    } //힙정렬에 사용되는 메소드 upHeap은 구현하지 않았다.
}
