import java.util.Arrays;

public class StudyGroup {
    int[] group;

    public boolean joinGroup(String student_num, String pw, int group) {
        return false;
    }

    public boolean exitGroup(String student_num, String pw, int group) {
        return false;
    }

    public boolean createGroup(String student_num, int group) {
        return false;
    }

    public boolean deleteGroup(String student_num, int group) {
        return false;
    }

    final byte SIZE = 16;
    private byte data[];
    private int index;

    public StudyGroup() {
        data = new byte[SIZE];
        index = 1;
        Arrays.fill(data, (byte) -1);
    }

    public void enqueue(byte data) {
        index = (index + 1) % SIZE;
        this.data[index] = data;
    }

    public byte getBit(int target) {
        return this.data[(index + target) % SIZE];
    }


    public void printAll() {
        for (int i = 1; i <= SIZE; i++) {
            byte temp = data[(index + i) % SIZE];
            if (temp == -1)
                System.out.print("-\t");
            else
                System.out.print(temp + "\t");
        }
        System.out.print("\n");
    }

    public void reset() {
        index = 0;
        Arrays.fill(data, (byte) -1);
    }
}
