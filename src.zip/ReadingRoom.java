
public class ReadingRoom {
    public int seat;

    public boolean checkSeat() {
        return false;
    }

    private String runNum;
    private int[] data;
    private ReadingRoom prev;
    private ReadingRoom next;

    public ReadingRoom() {
        prev = null;
        next = null;
    }

    public ReadingRoom(ReadingRoom prev, ReadingRoom next, int[] data, String runNum) {
        this.prev = prev;
        this.next = next;
        this.runNum = runNum;
        this.data = new int[data.length];

        for (int i = 0; i < data.length; i++)
            this.data[i] = data[i];
    }

    public ReadingRoom getPrev() {
        return this.prev;
    } 

    public ReadingRoom getNext() {
        return this.next;
    }

    public int[] getData() {
        return this.data;
    } 

    public String getRunNum() {
        return this.runNum;
    } 

    public void setPrev(ReadingRoom prev) {
        this.prev = prev;
    }

    public void setNext(ReadingRoom next) {
        this.next = next;
    }

    public void setData(int[] data) {
        this.data = data;
    } 

    public void printData() {
        for (int i = 0; i < data.length; i++)
            System.out.print(data[i] + " ");
        System.out.println("");
    }
}
