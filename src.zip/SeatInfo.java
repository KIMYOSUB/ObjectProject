
public class SeatInfo {
	private String name;
	private String student_num;
	public int seat;

	private byte checkFlat(byte curBit, byte preBit) {
		if (preBit == -1) {
			if (curBit == 0)
				return -2;
			else if (curBit == 1)
				return -1;
			else
				return 0;
		} else
			return 1;
	}

	public byte MenchEncoding(byte curBit, byte preBit) {
		{
			byte temp = checkFlat(curBit, preBit);
			if (temp != 1)
				return temp;
		}

		if (preBit == 0) {
			if (curBit == 0)
				return 1;
			else if (curBit == 1)
				return 2;
			else
				return 0;
		} else if (preBit == 1) {
			if (curBit == 0)
				return 3;
			else if (curBit == 1)
				return 4;
			else
				return 0;
		}
		return 0;
	}

	public byte defMenchEncoding(byte curBit, byte preBit, boolean even) {
		{
			byte temp = checkFlat(curBit, preBit);
			if (temp != 1)
				return temp;
		}

		if (even) {
			if (curBit == 0)
				return 1;
			else if (curBit == 1)
				return 2;
			else
				return 0;
		} else {
			if (curBit == 0)
				return 3;
			else if (curBit == 1)
				return 4;
			else
				return 0;
		}
	}
}
