import java.net.*;
import java.io.*;

class ChatServer{

	public static void main(String[] args) {
		int port = 7000;
		try{
			ServerSocket ss = new ServerSocket(port);
			while(true){
			Socket client = ss.accept();
			InputStream is = client.getInputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			PrintStream ps = new PrintStream(System.out);
			ps.print(client.getInetAddress().getHostAddress());
			ps.print("creat new Server" + reader.readLine());
			reader.close();
			ps.close();
			client.close();
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
