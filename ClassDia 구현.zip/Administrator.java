
public class Administrator {
	private String ad_id;
	private String ad_password;
	
	public boolean add(String name, String student_num){
		return false;
		
	}
	public boolean delete(String name, String student_num){
		return false;
		
	}
}
