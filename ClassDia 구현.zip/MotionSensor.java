
public class MotionSensor {
	public boolean movement(){
		return false;
	
	}
}
