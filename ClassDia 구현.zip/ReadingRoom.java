
public class ReadingRoom {
	public int seat;
	
	public boolean checkSeat(){
		return false;
	}
}
