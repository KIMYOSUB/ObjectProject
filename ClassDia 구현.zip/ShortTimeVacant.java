
public class ShortTimeVacant {
	public String name;
	public String student_num;
	
	public boolean checkVacant(int seat){
		return false;
		
	}
	public boolean antitheftAlarm(int seat){
		return false;
		
	}
	public boolean movement(){
		return false;
	
	}
}
