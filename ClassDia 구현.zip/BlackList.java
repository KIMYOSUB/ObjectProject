
public class BlackList {
	private String name;
	private String student_num;
	
	public boolean add(String name, String student_num){
		return false;
		
	}
	public boolean delete(String name, String student_num){
		return false;
		
	}
	public Student getStudent(String name, String student_num){
		return null;
		
	}
}
