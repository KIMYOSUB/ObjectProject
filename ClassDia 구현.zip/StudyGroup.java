
public class StudyGroup {
	int [] group;
	
	public boolean joinGroup(String student_num, String pw, int group){
		return false;
	}
	public boolean exitGroup(String student_num, String pw, int group){
		return false;
	}
	public boolean createGroup(String student_num, int group){
		return false;
	}
	public boolean deleteGroup(String student_num, int group){
		return false;
	}
}
