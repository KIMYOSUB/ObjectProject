
public class Student {
	private String name;
	private String student_num;
	private String pw;
	
	public boolean signIn(String student_num, String pw){
		return false;
		
	}
	public boolean signOut(String student_num, String pw){
		return false;
		
	}
	public boolean signUp(String student_num, String pw){
		return false;
	
	}
	public boolean rent(String student_num, String pw, int seat){
		return false;
		
	}
}