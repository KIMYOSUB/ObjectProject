
public class SeatInfo {
	private String name;
	private String student_num;
	public int seat;
	
	public boolean rent(String student_num, String pw, int seat){
		return false;
		
	}
	public boolean checkVacant(int seat){
		return false;
		
	}
	public boolean checkAbsence(int seat){
		return false;
		
	}
}
