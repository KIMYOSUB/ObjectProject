
public class Absence {
	public String name;
	public String student_num;
	
	public boolean checkAbsence(int seat){
		return false;
		
	}
	public boolean expandAlarm(int seat){
		return false;
		
	}
	public boolean movement(){
		return false;
	
	}
}
